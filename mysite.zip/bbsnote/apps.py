from django.apps import AppConfig


class BbsnoteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bbsnote'
